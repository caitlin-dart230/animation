let ellipsePostion = 0;
let ellipseSize = 0;
let x = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(11, 217, 186);
;
  
    //background oval
  strokeWeight(3);
  fill(255, 255, 255);
   ellipse(200,ellipsePostion+210, ellipseSize + 0);
  ellipse(200,ellipsePostion+250, ellipseSize + 0);
  ellipse(200,ellipsePostion+270, ellipseSize + 0);
    fill(247,255,10);
  //ellipse(100,ellipsePostion+350, ellipseSize + 10);
  ellipsePostion = ellipsePostion -0.1;
  ellipseSize = ellipseSize +0.5
  //foreground purple rectangle
  strokeWeight(2);
  stroke(20,100,59);
  fill(0,0,0);
  
  
  
  
  //outline rectangle
  fill(11, 158, 217);
  rect(0,350,600,90,10);
  
  //eyes
  strokeWeight(3);
  fill(29,121,130);
  ellipse(184,190,10,10);

  //other eye
  strokeWeight(3);
  fill(29,121,130);
  ellipse(210,190,10, 10);
  
  //snowman buttons
  strokeWeight(2);
  fill(0,0,0);
  ellipse(200,240,11,11);
  
  //second button
  strokeWeight(2);
  fill(0,0,0);
  ellipse(200,260,11,11);
  
  //third button
  strokeWeight(2);
  fill(0,0,0);
  ellipse(200,280,11,11);
  
  
  
  //mouth
  fill(6,0,0);
  line(215,200,180,199);
  

  
  
  noStroke();
  
 
   translate(200,200);
  rotate(radians(x));
  
  
  
  
 
  
  
   
  
  x = x + 1;
  
  
  
  
  
}